﻿
#include <iostream>          /*dev c++请使用#include<bits/stdc++.h>*/
using namespace std;
int main()
{
    cout << "Hello World!\n";
}